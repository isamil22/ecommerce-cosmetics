package com.example.demo.dto;

import lombok.Data;

@Data
public class UpdateQuantityRequest {
    private Integer quantity;
}
