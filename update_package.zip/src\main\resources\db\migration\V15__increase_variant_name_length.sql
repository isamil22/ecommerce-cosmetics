ALTER TABLE order_item MODIFY COLUMN variant_name VARCHAR(5000);
