import React from 'react';
import TrustBadges from '../TrustBadges'; // Adjusted import assuming this file is in components/home, need to go up one level if in components/home. 
// Wait, if I put this in src/components/home/WhyChooseUsSection.jsx, and TrustBadges is in src/components/TrustBadges.jsx:
// Path should be '../TrustBadges' if TrustBadges is in 'src/components' and this is in 'src/components/home' -> No, '../' goes to 'src/components'. Correct.

const WhyChooseUsSection = () => {
    return (
        <section className="relative w-full py-8 md:py-16 overflow-hidden bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50">
            {/* Background Decorations */}
            <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-pink-300/20 rounded-full blur-[100px] animate-pulse"></div>
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-purple-300/20 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '2s' }}></div>
            </div>

            <div className="container mx-auto px-6 relative z-10">

                {/* Section Header */}
                <div className="text-center mb-8 relative">
                    <div className="inline-block mb-2">
                        <span className="text-4xl animate-bounce inline-block">💎</span>
                    </div>
                    <h2 className="text-2xl md:text-5xl font-black text-gray-900 mb-2 tracking-tight drop-shadow-sm">
                        لماذا تختار متجرنا؟
                    </h2>
                    <h3 className="text-lg md:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-pink-600 to-purple-600 mb-4">
                        Pourquoi choisir notre boutique ?
                    </h3>
                    <div className="w-16 h-1 bg-gradient-to-r from-pink-500 to-purple-500 mx-auto rounded-full"></div>
                </div>

                {/* Features Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-12 max-w-7xl mx-auto">

                    {/* Card 1: Authentic Products */}
                    <div className="group relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-pink-500 to-purple-600 rounded-3xl blur opacity-20 group-hover:opacity-40 transition-opacity duration-500"></div>
                        <div className="relative h-full bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-5 shadow-lg transition-all duration-500 transform group-hover:-translate-y-2 group-hover:shadow-xl">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-white/40 to-transparent rounded-bl-full z-0 opacity-50"></div>

                            <div className="relative z-10 flex flex-col items-center text-center h-full">
                                <div className="w-16 h-16 bg-gradient-to-br from-red-100 to-pink-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500 shadow-inner">
                                    <span className="text-3xl">🎯</span>
                                </div>
                                <h4 className="text-lg font-black text-gray-800 mb-1">
                                    منتجات أصلية مضمونة
                                </h4>
                                <h5 className="text-sm font-bold text-pink-600 mb-2">
                                    100% Produits Authentiques
                                </h5>
                                <p className="text-gray-600 leading-relaxed font-medium text-sm">
                                    جميع منتجاتنا أصلية ومضمونة
                                    <br />
                                    <span className="text-xs text-gray-500 mt-1 block">
                                        Tous nos produits sont authentiques
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Card 2: Fast Shipping */}
                    <div className="group relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-3xl blur opacity-20 group-hover:opacity-40 transition-opacity duration-500"></div>
                        <div className="relative h-full bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-5 shadow-lg transition-all duration-500 transform group-hover:-translate-y-2 group-hover:shadow-xl">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-white/40 to-transparent rounded-bl-full z-0 opacity-50"></div>

                            <div className="relative z-10 flex flex-col items-center text-center h-full">
                                <div className="w-16 h-16 bg-gradient-to-br from-yellow-100 to-orange-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500 shadow-inner">
                                    <span className="text-3xl">🚚</span>
                                </div>
                                <h4 className="text-lg font-black text-gray-800 mb-1">
                                    توصيل سريع ومجاني
                                </h4>
                                <h5 className="text-sm font-bold text-orange-600 mb-2">
                                    Livraison Rapide et Gratuite
                                </h5>
                                <p className="text-gray-600 leading-relaxed font-medium text-sm">
                                    شحن مجاني لجميع الطلبات
                                    <br />
                                    <span className="text-xs text-gray-500 mt-1 block">
                                        Livraison gratuite sur toutes les commandes
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>

                    {/* Card 3: Premium Support */}
                    <div className="group relative">
                        <div className="absolute inset-0 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-3xl blur opacity-20 group-hover:opacity-40 transition-opacity duration-500"></div>
                        <div className="relative h-full bg-white/60 backdrop-blur-xl border border-white/50 rounded-2xl p-5 shadow-lg transition-all duration-500 transform group-hover:-translate-y-2 group-hover:shadow-xl">
                            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-white/40 to-transparent rounded-bl-full z-0 opacity-50"></div>

                            <div className="relative z-10 flex flex-col items-center text-center h-full">
                                <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-500 shadow-inner">
                                    <span className="text-3xl">💎</span>
                                </div>
                                <h4 className="text-lg font-black text-gray-800 mb-1">
                                    خدمة عملاء متميزة
                                </h4>
                                <h5 className="text-sm font-bold text-blue-600 mb-2">
                                    Service Client Premium
                                </h5>
                                <p className="text-gray-600 leading-relaxed font-medium text-sm">
                                    فريق دعم متاح 24/7 لمساعدتك
                                    <br />
                                    <span className="text-xs text-gray-500 mt-1 block">
                                        Équipe d'assistance disponible 24/7
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Trust Badges Integration */}
                <div className="hidden md:block mt-20 transform hover:scale-[1.02] transition-transform duration-500">
                    <TrustBadges />
                </div>
            </div>
        </section>
    );
};

export default WhyChooseUsSection;
