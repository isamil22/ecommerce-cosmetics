ALTER TABLE order_item MODIFY COLUMN product_image MEDIUMTEXT;
