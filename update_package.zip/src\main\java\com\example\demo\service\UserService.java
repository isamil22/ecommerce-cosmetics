package com.example.demo.service;

import com.example.demo.dto.ChangePasswordRequest;
import com.example.demo.dto.UserDTO;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.mapper.UserMapper;
import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.repositories.CommentRepository;
import com.example.demo.repositories.OrderRepository;
import com.example.demo.repositories.ReviewRepository;
import com.example.demo.repositories.RoleRepository;
import com.example.demo.repositories.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final UserMapper userMapper;
    private final OrderRepository orderRepository;
    private final CommentRepository commentRepository;
    private final ReviewRepository reviewRepository;
    private final RoleRepository roleRepository;
    // Removed RecaptchaService dependency as it's no longer used in this service for validation
    // private final RecaptchaService recaptchaService;

    @Value("${frontend.url}")
    private String frontendUrl;

    public User registerUser(User user){
        // Removed reCAPTCHA validation from here as it's now handled at the controller layer (AuthController)
        // if (!recaptchaService.validateRecaptcha(user.getRecaptchaToken())) {
        //     throw new BadCredentialsException("reCAPTCHA validation failed. Please try again.");
        // }

        if(userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new IllegalStateException("Email already taken");
        }
        
        // Encode password and set user properties
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole(User.Role.USER);
        user.setConfirmationCode(generateConfirmationCode());
        user.setEmailConfirmation(false);
        
        // Assign default RBAC role (ROLE_USER) to new users
        try {
            Role defaultRole = roleRepository.findByName("ROLE_USER")
                .orElseGet(() -> {
                    // If ROLE_USER doesn't exist in DB, log warning but continue
                    return null;
                });
            if (defaultRole != null) {
                user.addRole(defaultRole);
            }
        } catch (Exception e) {
            // Log error but don't fail registration if RBAC role assignment fails
            System.err.println("Warning: Could not assign RBAC role to new user: " + e.getMessage());
        }
        
        // Save user to database first
        User savedUser = userRepository.save(user);
        
        // Send confirmation email (non-blocking - don't fail registration if email fails)
        try {
            emailService.sendConfirmationCode(savedUser);
        } catch (Exception e) {
            // Log the error but don't fail the registration
            System.err.println("ERROR: Failed to send confirmation email to " + savedUser.getEmail());
            System.err.println("Email error details: " + e.getMessage());
            e.printStackTrace();
            // User is still created successfully, they just won't get the email
        }
        
        return savedUser;
    }

    public User getUserByEmail(String email){
        return userRepository.findByEmailWithRolesAndPermissions(email).orElseThrow(()-> new ResourceNotFoundException("User not found"));
    }

    public void changePassword(String email, ChangePasswordRequest request){
        User user = getUserByEmail(email);
        if(!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw new BadCredentialsException("Current password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
    }

    public void confirmEmail(String email, String confirmationCode){
        User user = getUserByEmail(email);
        if(user.getConfirmationCode().equals(confirmationCode)){
            user.setEmailConfirmation(true);
            user.setConfirmationCode(null);
            userRepository.save(user);
        }
        else{
            throw new BadCredentialsException("Invalid confirmation code");
        }
    }

    private String generateConfirmationCode(){
        Random random = new Random();
        int code = 100000 + random.nextInt(900000);
        return String.valueOf(code);
    }

    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    public List<UserDTO> getAllUsers() {
        return userMapper.toDTOs(userRepository.findAll());
    }

    @Transactional
    public void deleteUser(Long id) {
        if (!userRepository.existsById(id)) {
            throw new ResourceNotFoundException("User not found with id: " + id);
        }
        // Corrected method call from findByUserId to findByUser_Id
        orderRepository.deleteAll(orderRepository.findByUser_Id(id));
        commentRepository.deleteAll(commentRepository.findByUserId(id));
        reviewRepository.deleteAll(reviewRepository.findByUserId(id));
        userRepository.deleteById(id);
    }

    public UserDTO updateUserRole(Long id, User.Role role) {
        User user = getUserById(id);
        user.setRole(role);
        User updatedUser = userRepository.save(user);
        return userMapper.toDTO(updatedUser);
    }

    public void forgotPassword(String email) {
        User user = getUserByEmail(email);
        String token = UUID.randomUUID().toString();
        user.setResetPasswordToken(token);
        user.setResetPasswordTokenExpiry(LocalDateTime.now().plusHours(1)); // Token is valid for 1 hour
        userRepository.save(user);
        String resetLink = frontendUrl + "/reset-password/" + token;
        emailService.sendPasswordResetEmail(user, resetLink);
    }

    public void resetPassword(String token, String newPassword) {
        User user = userRepository.findByResetPasswordToken(token)
                .orElseThrow(() -> new ResourceNotFoundException("Invalid password reset token"));

        if (user.getResetPasswordTokenExpiry().isBefore(LocalDateTime.now())) {
            throw new BadCredentialsException("Password reset token has expired");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        user.setResetPasswordToken(null);
        user.setResetPasswordTokenExpiry(null);
        userRepository.save(user);
    }
    
    /**
     * Assign roles to a user (replaces existing roles)
     */
    @Transactional
    public UserDTO assignRoles(Long userId, java.util.Set<Long> roleIds) {
        User user = getUserById(userId);
        
        // Clear existing roles
        user.getRoles().clear();
        
        // Add new roles
        if (roleIds != null && !roleIds.isEmpty()) {
            java.util.Set<Role> roles = new java.util.HashSet<>(roleRepository.findAllById(roleIds));
            for (Role role : roles) {
                user.addRole(role);
            }
        }
        
        User updatedUser = userRepository.save(user);
        return userMapper.toDTO(updatedUser);
    }
    
    /**
     * Add a role to a user
     */
    @Transactional
    public UserDTO addRole(Long userId, Long roleId) {
        User user = getUserById(userId);
        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + roleId));
        
        user.addRole(role);
        
        User updatedUser = userRepository.save(user);
        return userMapper.toDTO(updatedUser);
    }
    
    /**
     * Remove a role from a user
     */
    @Transactional
    public UserDTO removeRole(Long userId, Long roleId) {
        User user = getUserById(userId);
        Role role = roleRepository.findById(roleId)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found with id: " + roleId));
        
        user.removeRole(role);
        
        User updatedUser = userRepository.save(user);
        return userMapper.toDTO(updatedUser);
    }
}