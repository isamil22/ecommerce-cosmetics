

git reset --hard 1b6d222f8a332bab17c33d4fdc995a4251e96537

git push origin main --force

docker-compose logs backend

docker-compose logs frontend  


https://skintereststore.ma/detailproduit/cosrx-bha-blackhead-power-liquid