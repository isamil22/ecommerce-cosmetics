package com.example.demo.dto;

import lombok.Data;

@Data
public class UpdateDefaultProductRequestDTO {
    private Long productId;
}